import Vars
import subVars


class item:
    def __init__(self, name, price, effect, ownership, usable):
        self.usable = usable
        self.ownership = ownership
        self.effect = effect
        self.name = name
        self.price = price


CCard = item("CasinoCard", 25, 15, False, True)


Beer = item("Beer", 5, 25, False, True)

def purchasing():
    global CCard
    print(
        f"{CCard.name}, is for {CCard.price}, and it gives you {CCard.effect}+ more money in your payment when you win."
    )
    print(
        f"{Beer.name}, is for {Beer.price}, and it gives you {Beer.effect}+ sanity so you don't go insane."
    )
    Buy = input("Choose an item to purchase, or don't.\n")
    if Buy == CCard.name:
        ccPurch()
    elif Buy == Beer.name:
        BeerPurch()
    else:
        print("Nothing was chosen, or you mispelled something.")

# Item's effects and their corresponding purchase code
def BeerPurch():
    global Beer
    if Vars.Balance >= Beer.price:
        Vars.Balance -= Beer.price
        print(f"Your balance is now {Vars.Balance}")
        Beer.usable = True
        Beer.ownership = True
    else:
        print("No moneys")
def ccPurch():
    global CCard
    if CCard.ownership == False and Vars.Balance >= CCard.price:
        Vars.Balance -= CCard.price
        print(f"Your balance is now {Vars.Balance}")
        CCard.usable = True
        CCard.ownership = True
    elif CCard.ownership == True:
        print("You already own this?")
    else:
        print("no money")


def ccFunc():
    if CCard.ownership is True and CCard.usable is True:
        Vars.Pay = Vars.Pay + 15
        CCard.usable = False
def BeerFunc():
    if Beer.ownership is True and Beer.usable is True:
        Vars.Sanity = Vars.Sanity + 25
        Beer.usable = False
        Beer.ownership = False
def items():
    ccFunc()
    BeerFunc()