import Vars
import subVars
import os
import Dictionaries
print("Vers 0.3")
print("Rewritten project, I made the first version of this really messy,\nso I decided to rewrite it.")
Start = input("Type in your desired task (USE CAPS). \n[PLAY]      [UPDATELOG]     [SETTINGS]\n")
if Start == "PLAY":
    print("Starting...")
    Vars.play()
elif Start == "UPDATELOG":
    Vars.Changelog()
else:
    Vars.play()