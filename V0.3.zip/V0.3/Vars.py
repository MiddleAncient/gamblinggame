# vars
import time
import random
import os

import Dictionaries
import subVars
from colorama import Fore, Back, Style
import sys
TPat = 100
TDays = 7
baseTAmount = 15
ExtraAmount = 0
check = 0
Balance = 30
Sanity = 100
Pay = 20
No1 = 1
No2 = 2
BNo1 = random.randint(1,2)
BNo2 = random.randint(1,2)
# functions
def play():
    print(Fore.CYAN + "COLOR CHECK COLOR CHECK")
    print(Fore.RESET)
    os.system('cls')
    global check
    global BNo1
    global BNo2
    global No1
    global No2
    global Pay
    global Balance
    while check == 0:
        Balance = Balance - 5
        if Balance <= 0:
            Balance = 0
        subVars.checkBreaker()
        subVars.choose()
        subVars.checkBreaker()
        subVars.Randomize()
        subVars.checkBreaker()
        subVars.Results()
        subVars.checkBreaker()
        subVars.Taxes()
        subVars.Shop()
        Dictionaries.items()
        subVars.Summary()
        print("=========================================================================================================")
        subVars.clear()
    if check == 1:
        print("Lost by insufficient balance.")
    if check == 2:
        print("Lost by failed tax evasion")
    if check == 3:
        print("Lost by insanity")
    print("You lost. Thanks for playing! If there is a bug, please hit me up @ MiddleAncient#2269 as I am \nconstantly looking to fix bugs. I also take suggestions. Thank you!!")
    print("For the window to close immediately, just click out, or wait 20 seconds...")
    time.sleep(10)
    os.system('cls')
def Changelog():
    subVars.clear()
    print(Fore.LIGHTCYAN_EX + "0.1")
    print("-Betting\n-Summary\n-Pay")
    print("0.2")
    print("-Dynamic tax system\n-Shop prototype\n COLORED TEXT!?!?")
    print("0.3")
    print("-Revamped shop system\n-Functioning items in shop\n-Insanity stat\n-Base tax amount is now based off of your balance caps at 200 for now\n-WORKING UPDATELOG!?!!?!? (CRAZY)")
    time.sleep(600)